Configuration Main
{

Param ( [string] $nodeName )

Import-DscResource -ModuleName PSDesiredStateConfiguration
Import-DscResource -ModuleName xNetworking



Node $nodeName
  {

	xFirewall Firewall
        {
            Name                  = "FERules"
            DisplayName           = "Outsystems front-end rules"
			Group                 = "Outsystems"
            Action                = "Allow"
            Enabled               = "True"
            Profile               = "Any"
            Direction             = "Inbound"
            RemotePort            = ("Any")
            LocalPort             = ("12000", "12001", "12002", "12003", "12004")         
            Protocol              = "TCP"
            Description           = "FE Server Ports" 
        }

	  WindowsFeature WebServerRole
		{
			Name = "Web-Server"
			Ensure = "Present"
			IncludeAllSubFeature = "True"
		}
	  WindowsFeature WebServer
	  {
			Name = "Web-WebServer"
			Ensure = "Present"
			IncludeAllSubFeature = "True"
	  }
	WindowsFeature AppDev
	  {
			Name = "Web-App-Dev"
			Ensure = "Present"
			IncludeAllSubFeature = "True"
	  }

	WindowsFeature NetEXT35
	  {
			Name = "Web-Net-Ext"
			Ensure = "Present"
			IncludeAllSubFeature = "True"
	  }

	WindowsFeature ASPNet
	  {
			Name = "Web-Net-Ext45"
			Ensure = "Present"
			IncludeAllSubFeature = "True"
	  }


	WindowsFeature ISAPIExt
	  {
			Name = "Web-ISAPI-Ext"
			Ensure = "Present"
			IncludeAllSubFeature = "True"
	  }

	WindowsFeature ISAPIFilter
	  {
			Name = "Web-ISAPI-Filter"
			Ensure = "Present"
			IncludeAllSubFeature = "True"
	  }

	WindowsFeature WebCommon
	  {
			Name = "Web-Common-http"
			Ensure = "Present"
			IncludeAllSubFeature = "True"
	  }

	WindowsFeature DefDoc
	  {
			Name = "Web-Default-Doc"
			Ensure = "Present"
			IncludeAllSubFeature = "True"
	  }
	WindowsFeature DirBrowsing
	  {
			Name = "Web-Dir-Browsing"
			Ensure = "Present"
			IncludeAllSubFeature = "True"
	  }
	WindowsFeature HTTPErrors
	  {
			Name = "Web-Http-Errors"
			Ensure = "Present"
			IncludeAllSubFeature = "True"
	  }
	WindowsFeature StaticCont
	  {
			Name = "Web-Static-Content"
			Ensure = "Present"
			IncludeAllSubFeature = "True"
	  }
	WindowsFeature Health
	  {
			Name = "Web-Health"
			Ensure = "Present"
			IncludeAllSubFeature = "True"
	  }
	WindowsFeature HTTPlog
	  {
			Name = "Web-Http-Logging"
			Ensure = "Present"
			IncludeAllSubFeature = "True"
	  }
	WindowsFeature RequestMon
	  {
			Name = "Web-Request-Monitor"
			Ensure = "Present"
			IncludeAllSubFeature = "True"
	  }
	WindowsFeature Performance
	  {
			Name = "Web-Performance"
			Ensure = "Present"
			IncludeAllSubFeature = "True"
	  }
	WindowsFeature DynamicContent
	  {
			Name = "Web-Dyn-Compression"
			Ensure = "Present"
			IncludeAllSubFeature = "True"
	  }
	WindowsFeature StaticCompression
	  {
			Name = "Web-Stat-Compression"
			Ensure = "Present"
			IncludeAllSubFeature = "True"
	  }
	WindowsFeature Security
	  {
			Name = "Web-Security"
			Ensure = "Present"
			IncludeAllSubFeature = "True"
	  }
	WindowsFeature RequestFiltering
	  {
			Name = "Web-Filtering"
			Ensure = "Present"
			IncludeAllSubFeature = "True"
	  }
	WindowsFeature WindowsAuthentication
	  {
			Name = "Web-Windows-Auth"
			Ensure = "Present"
			IncludeAllSubFeature = "True"
	  }
	WindowsFeature ManagementTools
	  {
			Name = "Web-Mgmt-Tools"
			Ensure = "Present"
			IncludeAllSubFeature = "True"
	  }
	 WindowsFeature IISManagement
	  {
			Name = "Web-Mgmt-Compat"
			Ensure = "Present"
			IncludeAllSubFeature = "True"
	  }
	WindowsFeature IISmetabase
	  {
			Name = "Web-Metabase"
			Ensure = "Present"
			IncludeAllSubFeature = "True"
	  }
	WindowsFeature IISmanagementconsole
	  {
			Name = "Web-Mgmt-Console"
			Ensure = "Present"
			IncludeAllSubFeature = "True"
	  }

	 WindowsFeature MessageQueuing
	  {
			Name = "MSMQ"
			Ensure = "Present"
			IncludeAllSubFeature = "True"
	  }
	 WindowsFeature MessageQueuingService
	  {
			Name = "MSMQ-Services"
			Ensure = "Present"
			IncludeAllSubFeature = "True"
	  }
	WindowsFeature MessageQueuingServer
	  {
			Name = "MSMQ-Server"
			Ensure = "Present"
			IncludeAllSubFeature = "True"
	  }
	WindowsFeature WindowsProcessActivation
	  {
			Name = "WAS"
			Ensure = "Present"
			IncludeAllSubFeature = "True"
	  }
	WindowsFeature WASNETenv
	  {
			Name = "WAS-NET-Environment"
			Ensure = "Present"
			IncludeAllSubFeature = "True"
	  }
	WindowsFeature WASAPIs
	  {
			Name = "WAS-Config-APIs"
			Ensure = "Present"
			IncludeAllSubFeature = "True"
	  }

	WindowsFeature WASProcessModel
	  {
			Name = "WAS-Process-Model"
			Ensure = "Present"
			IncludeAllSubFeature = "True"
	  }

	Script SetRegistry
    {

		TestScript = {
		$exists = Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\MSMQ\Parameters\Setup" -Name "AlwaysWithoutDS" -ErrorAction SilentlyContinue
		If (($exists -ne $null) -and ($exists.Length -ne 0)) {
			Return $true
		}
			Return $false
		}
     
        SetScript ={
			New-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\MSMQ\Parameters\Setup" -Name "AlwaysWithoutDS" -PropertyType DWORD -Value "1"
        }

		GetScript = {@{Result = "SetRegistry"}}
		DependsOn = "[WindowsFeature]MessageQueuing"

		}
    }
  }
