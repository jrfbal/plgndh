Configuration Main
{

Param ( [string] $nodeName )

Import-DscResource -ModuleName PSDesiredStateConfiguration
Import-DscResource -ModuleName xNetworking

Node $nodeName
  {

	xFirewall Firewall
        {
            Name                  = "FERules"
            DisplayName           = "Outsystems front-end rules"
			Group                 = "Outsystems"
            Action                = "Allow"
            Enabled               = "True"
            Profile               = "Any"
            Direction             = "Inbound"
            RemotePort            = ("Any")
            LocalPort             = ("12000", "12001", "12002", "12003", "12004")         
            Protocol              = "TCP"
            Description           = "FE Server Ports" 
        }
		
	WindowsFeature WebServerRole
		{
			Name = "Web-Server"
			Ensure = "Present"
		}

	WindowsFeature WebServer
	  {
			Name = "Web-WebServer"
			Ensure = "Present"
	  }
	WindowsFeature AppDev
	  {
			Name = "Web-App-Dev"
			Ensure = "Present"
	  }

	WindowsFeature NetEXT35
	  {
			Name = "Web-Net-Ext"
			Ensure = "Present"
	  }

	WindowsFeature ASPNet
	  {
			Name = "Web-Net-Ext45"
			Ensure = "Present"
	  }


	WindowsFeature ISAPIExt
	  {
			Name = "Web-ISAPI-Ext"
			Ensure = "Present"
	  }

	WindowsFeature ISAPIFilter
	  {
			Name = "Web-ISAPI-Filter"
			Ensure = "Present"
	  }

	WindowsFeature WebCommon
	  {
			Name = "Web-Common-http"
			Ensure = "Present"
	  }

	WindowsFeature DefDoc
	  {
			Name = "Web-Default-Doc"
			Ensure = "Present"
	  }
	WindowsFeature DirBrowsing
	  {
			Name = "Web-Dir-Browsing"
			Ensure = "Present"
	  }
	WindowsFeature HTTPErrors
	  {
			Name = "Web-Http-Errors"
			Ensure = "Present"
	  }
	WindowsFeature StaticCont
	  {
			Name = "Web-Static-Content"
			Ensure = "Present"
	  }
	WindowsFeature Health
	  {
			Name = "Web-Health"
			Ensure = "Present"
	  }
	WindowsFeature HTTPlog
	  {
			Name = "Web-Http-Logging"
			Ensure = "Present"
	  }
	WindowsFeature RequestMon
	  {
			Name = "Web-Request-Monitor"
			Ensure = "Present"
	  }
	WindowsFeature Performance
	  {
			Name = "Web-Performance"
			Ensure = "Present"
	  }
	WindowsFeature DynamicContent
	  {
			Name = "Web-Dyn-Compression"
			Ensure = "Present"
	  }
	WindowsFeature StaticCompression
	  {
			Name = "Web-Stat-Compression"
			Ensure = "Present"
	  }
	WindowsFeature Security
	  {
			Name = "Web-Security"
			Ensure = "Present"
	  }
	WindowsFeature RequestFiltering
	  {
			Name = "Web-Filtering"
			Ensure = "Present"
	  }
	WindowsFeature WindowsAuthentication
	  {
			Name = "Web-Windows-Auth"
			Ensure = "Present"
	  }
	WindowsFeature ManagementTools
	  {
			Name = "Web-Mgmt-Tools"
			Ensure = "Present"
	  }
	 WindowsFeature IISManagement
	  {
			Name = "Web-Mgmt-Compat"
			Ensure = "Present"
	  }
	WindowsFeature IISmetabase
	  {
			Name = "Web-Metabase"
			Ensure = "Present"
	  }
	WindowsFeature IISmanagementconsole
	  {
			Name = "Web-Mgmt-Console"
			Ensure = "Present"
	  }

	 WindowsFeature MessageQueuing
	  {
			Name = "MSMQ"
			Ensure = "Present"
	  }
	 WindowsFeature MessageQueuingService
	  {
			Name = "MSMQ-Services"
			Ensure = "Present"
	  }
	WindowsFeature MessageQueuingServer
	  {
			Name = "MSMQ-Server"
			Ensure = "Present"
	  }
	WindowsFeature WindowsProcessActivation
	  {
			Name = "WAS"
			Ensure = "Present"
	  }
	WindowsFeature WASNETenv
	  {
			Name = "WAS-NET-Environment"
			Ensure = "Present"
	  }
	WindowsFeature WASAPIs
	  {
			Name = "WAS-Config-APIs"
			Ensure = "Present"
	  }

	WindowsFeature WASProcessModel
	  {
			Name = "WAS-Process-Model"
			Ensure = "Present"
	  }


    }
  }
