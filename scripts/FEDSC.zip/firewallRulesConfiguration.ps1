Configuration Main
{

Param ( [string] $nodeName )

Install-Module -Name xNetworking -Force

Import-DscResource -ModuleName PSDesiredStateConfiguration
Import-DscResource -ModuleName xNetworking



Node $nodeName
  {

	        xFirewall Firewall
        {
            Name                  = "FERules"
            DisplayName           = "Outsystems front-end rules"
            Ensure                = "Present"
            Action                = "Permit"
            Enabled                = "True"
            Profile               = ("Domain", "Private", "Internet")
            Direction             = "Inbound"
            RemotePort            = "Any"
            LocalPort             = "12000 - 12005"         
            Protocol              = "TCP"
            Description           = "FE Server Ports"  
        }
  }
}