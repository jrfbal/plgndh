Configuration Main
{

Param ( [string] $nodeName )

Import-DscResource -ModuleName PSDesiredStateConfiguration
Import-DscResource -ModuleName xNetworking

Node $nodeName
  {

	WindowsFeature WebServerRole
		{
			Name = "Web-Server"
			Ensure = "Present"
		}




    }
  }
