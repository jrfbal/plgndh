Configuration Main
{

Param ( [string] $nodeName )

Import-DscResource -ModuleName PSDesiredStateConfiguration
Import-DscResource -ModuleName xNetworking



Node $nodeName
  {

	        xFirewall Firewall
        {
            Name                  = "FERules"
            DisplayName           = "Outsystems front-end rules"
            Ensure                = "Present"
            Action                = "Allow"
            Enabled                = "True"
            Profile               = ("Domain", "Private", "Internet")
            Direction             = "Inbound"
            RemotePort            = ("*")
            LocalPort             = ("12000", "12001", "12002", "12003", "12004", "12005")         
            Protocol              = "TCP"
            Description           = "FE Server Ports"  
        }
  }
}