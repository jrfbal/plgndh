Configuration Main
{

Param ( [string] $nodeName )

Import-DscResource -ModuleName PSDesiredStateConfiguration
Import-DscResource -ModuleName xNetworking



Node $nodeName
  {

	        xFirewall Firewall
        {
            Name                  = "FERules"
            DisplayName           = "Outsystems front-end rules"
			Group                 = "Outsystems"
            Action                = "Allow"
            Enabled               = "True"
            Profile               = "Any"
            Direction             = "Inbound"
            RemotePort            = ("Any")
            LocalPort             = ("12000", "12001", "12002", "12003", "12004")         
            Protocol              = "TCP"
            Description           = "FE Server Ports" 
        }
  }
}